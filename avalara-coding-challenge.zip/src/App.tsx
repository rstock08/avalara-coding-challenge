import './App.css';
import FormContainer from './containers/FormContainer';

function App() {
  return (
    <FormContainer />
  );
}

export default App;
